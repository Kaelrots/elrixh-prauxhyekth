// Node.js 모의환경 검사. 실제 Obsidian/Templater를 구동하는 시험이 아니다.
// 의존: Node.js 및 PyYAML이 설치된 python. 실행: node 검증/test_renderer.js
const fs = require('fs');
const path = require('path');
const assert = require('assert/strict');
const crypto = require('crypto');
const { execFileSync } = require('child_process');
const root = path.resolve(__dirname, '..');
const renderer = require(path.join(root, '적용파일/유저 스크립트/render_frontmatter.js'));
const original = fs.readFileSync(path.join(root, '적용파일/00-yaml 속성탭.md'), 'utf8');
const sourcePath = '90-볼트 운영/00-템플릿/00-yaml 속성탭.md';
const sourceFile = { path: sourcePath, extension: 'md', basename: '00-yaml 속성탭' };
const yamlBridge = String.raw`
import sys,json,yaml
from yaml.constructor import ConstructorError
class StrictLoader(yaml.SafeLoader): pass
def mapping(loader,node,deep=False):
    out={}
    for k,v in node.value:
        key=loader.construct_object(k,deep=deep)
        if key in out: raise ConstructorError('mapping',node.start_mark,'duplicate key: '+str(key),k.start_mark)
        out[key]=loader.construct_object(v,deep=deep)
    return out
StrictLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,mapping)
data=sys.stdin.read()
if sys.argv[1]=='load':
    print(json.dumps(yaml.load(data,Loader=StrictLoader),ensure_ascii=False))
else:
    print(yaml.safe_dump(json.loads(data),allow_unicode=True,sort_keys=False),end='')
`;
function load(text){ return JSON.parse(execFileSync('python',['-c',yamlBridge,'load'],{input:text,encoding:'utf8'})); }
function dump(data){ return execFileSync('python',['-c',yamlBridge,'dump'],{input:JSON.stringify(data),encoding:'utf8'}); }
const baseValues = () => ({ '문서유형':'entity','세부유형':'person','분야':['인물'],
  '사용된 템플릿':'04-인물 설정 템플릿 V2 파일럿','템플릿 버전':'2.0.0-pilot.2','기준시점':null });
function mock(config={}){
  const state={source:config.source??original,target:config.targetContent??'',writes:0,includes:0};
  const target={path:config.targetPath??'시험/가상 인물.md',extension:'md',basename:'가상 인물'};
  const source={...sourceFile,path:config.sourcePath??sourcePath};
  const app={vault:{
    read:async file => file.path===source.path?state.source:state.target,
    getAbstractFileByPath:p => !config.missingSource && p===source.path?source:null,
    modify:()=>{state.writes++;throw Error('write forbidden');},
    create:()=>{state.writes++;throw Error('write forbidden');},
  }};
  const tp={app,config:{target_file:target,template_file:{path:'템플릿/인물.md'}},
    date:{now:()=> '2026-10-02T16:00:00'},
    obsidian:{parseYaml:load,stringifyYaml:dump},
    file:{title:config.title??'가상 인물',include:async file=>{
      state.includes++;
      assert.equal(file.path,source.path);
      const text=state.source.replace(/<%\s*([\s\S]*?)\s*%>/g,(_,expr)=>new Function('tp',`return (${expr});`)(tp));
      if(config.changeSource) state.source+='\n# concurrent change\n';
      if(config.changeTarget) state.target='다른 편집기가 입력함';
      return text;
    }}
  };
  tp.user={render_frontmatter:renderer};
  return {tp,state};
}
function parsed(text){ return load(text.match(/^---\n([\s\S]*?)\n---\n$/)[1]); }
const results=[];
async function test(name,fn){
  try{await fn(); results.push({name,result:'PASS'});}
  catch(e){results.push({name,result:'FAIL',error:e.stack});}
}
async function generate(values={},options={},config={}){
  const {tp,state}=mock(config);
  const out=await renderer(tp,{...options,values:{...baseValues(),...values}});
  assert.equal(state.writes,0);
  return {out,data:parsed(out),state};
}
async function rejects(values={},options={},config={}){
  const {tp,state}=mock(config);
  await assert.rejects(renderer(tp,{...options,values:{...baseValues(),...values}}));
  assert.equal(state.writes,0);
}
(async()=>{
 await test('신규 인물: 원본 기본값과 호출부 병합',async()=>{
  const {data,state}=await generate();
  assert.equal(data['제목'],'가상 인물');assert.equal(data['문서유형'],'entity');
  assert.equal(data['스키마버전'],'2.0.0');assert.equal(data['템플릿 버전'],'2.0.0-pilot.2');
  assert.equal(data['정본상태'],'draft');assert.equal(data.draft,true);
  assert.equal(data['복원여부'],false);assert.equal(state.includes,1);
 });
 await test('미사용 선택필드는 생략, 명시된 기준시점 null은 유지',async()=>{
  const {data}=await generate();
  for(const key of ['연속성','상위개념','하위개념','permalink','최종검토일','복원원문문서명']) assert(!Object.hasOwn(data,key));
  assert(Object.hasOwn(data,'기준시점'));assert.equal(data['기준시점'],null);
 });
 await test('연속성·개념관계·공개주소·별칭 선택값 전달',async()=>{
  const fields={ '연속성':['B루트'],'상위개념':['[[상위 개념]]'],'하위개념':['[[하위 개념]]'],
   permalink:'/stable/sample',aliases:['인물 별칭','/old/public/sample'] };
  const {data}=await generate(fields);for(const [k,v] of Object.entries(fields))assert.deepEqual(data[k],v);
 });
 await test('원본에서 원창작→복원으로 지정하면 호환값 true',async()=>{
  const {data}=await generate({'기원상태':'restored','복원원문문서명':'옛 기록.md','복원원문최초작성일':'2015년 추정'});
  assert.equal(data['복원여부'],true);assert.equal(data['복원원문최초작성일'],'2015년 추정');
  assert.equal(data['복원원문최종수정일'],null);
 });
 await test('기원 불명은 null, false/original로 추정하지 않음',async()=>{
  const {data}=await generate({'기원상태':null});assert.equal(data['기원상태'],null);assert.equal(data['복원여부'],null);
 });
 for(const kind of ['master','concept','entity','reference','index','report','template','archive','event','period','rule','ledger']){
  await test(`문서유형 ${kind} 보존·허용`,async()=>assert.equal((await generate({'문서유형':kind})).data['문서유형'],kind));
 }
 await test('미정의 유형 거부',()=>rejects({'문서유형':'made_up'}));
 await test('정본 자동승격 거부',()=>rejects({'정본상태':'canon'}));
 await test('신규 즉시 공개값 주입 거부',()=>rejects({draft:false}));
 await test('생성일 기본값 재정의 거부',()=>rejects({'최초작성일':'2000-01-01'}));
 await test('스키마 버전 숫자만 변경하는 호출 거부',()=>rejects({'스키마버전':'9.9.9'}));
 await test('출처와 original 모순 거부',()=>rejects({'복원원문문서명':'old.md'}));
 await test('확장 공통키 충돌 거부',()=>rejects({}, {extensions:{draft:false}}));
 await test('기술 고유 ID/doc_type/전용 속성 유지',async()=>{
  const x={gate_id:'G2-01-001',doc_type:'gate_node',prereq_hard:['G2-01-000']};
  const {data}=await generate({'세부유형':'gate_node'},{extensions:x});
  for(const [k,v] of Object.entries(x))assert.deepEqual(data[k],v);
 });
 await test('명칭 태그의 공백을 자동수선하지 않고 거부',()=>rejects({tags:['공백 태그']}));
 await test('잘못된 목록 자료형 거부',()=>rejects({'분야':'인물'}));
 await test('종래 키를 신규 출력에 재도입하면 거부',()=>rejects({}, {extensions:{'카테고리':'옛 폴더'}}));
 await test('임의 물리경로 필드 생성 거부',()=>rejects({}, {extensions:{'경로':'폴더/파일.md'}}));
 await test('필수 템플릿명 누락 거부',()=>rejects({'사용된 템플릿':null}));
 await test('원본 미발견 시 fallback 없이 중단',()=>rejects({}, {}, {missingSource:true}));
 await test('원본에 본문이 섞이면 거부',()=>rejects({}, {}, {source:original+'\n# 본문\n'}));
 await test('중복 YAML 키 거부',()=>rejects({}, {}, {source:original.replace('aliases: []','aliases: [] # @type=list\naliases: []')}));
 await test('기존 공개문서의 상태·날짜·주소를 건드리지 않음',async()=>{
  const content='---\n정본상태: canon\ndraft: false\n최초작성일: 2015-01-01\npermalink: /old/url\n알수없는키: 유지\n---\n# 기존 문서';
  const {tp,state}=mock({targetContent:content});await assert.rejects(renderer(tp,{values:baseValues()}));
  assert.equal(state.target,content);assert.equal(state.writes,0);
 });
 await test('프론트매터만 있는 기존문서도 거부',()=>rejects({}, {}, {targetContent:'---\ntitle: existing\n---\n'}));
 await test('공통 원본 자체 실행 거부',()=>rejects({}, {}, {targetPath:sourcePath}));
 await test('다른 활성문서를 대상으로 삼지 않음',async()=>{
  const {tp,state}=mock();tp.app.workspace={getActiveFile:()=>{throw Error('should not be called');}};
  await renderer(tp,{values:baseValues()});assert.equal(state.writes,0);
 });
 await test('생성 도중 원본 변경 감지',()=>rejects({}, {}, {changeSource:true}));
 await test('생성 도중 대상 변경 감지',()=>rejects({}, {}, {changeTarget:true}));
 await test('B루트 경로에서 연속성 누락 거부',()=>rejects({}, {}, {targetPath:'80-대체루트·비정사/01-신계 B루트/시험.md'}));
 await test('B루트 명시 시 생성 가능',async()=>assert.deepEqual((await generate({'연속성':['B루트']},{},
  {targetPath:'80-대체루트·비정사/01-신계 B루트/시험.md'})).data['연속성'],['B루트']));
 for(const title of ['이름: 부제','"따옴표" 인물','위키 [[표현]]','# 주석처럼 보이는 제목','줄\n바꿈','백슬래시\\기록']){
  await test(`특수 제목 직렬화: ${JSON.stringify(title)}`,async()=>assert.equal((await generate({}, {}, {title})).data['제목'],title));
 }
 await test('단일원본 변경이 호출부 변경 없이 출력에 반영',async()=>{
  const source=original.replace('작성자: 현카엘','작성자: 변경시험작성자').replace('cssclasses: []', '신규선택속성: null # @type=string @nullable @optional\ncssclasses: []');
  const {data}=await generate({'신규선택속성':'읽기 시험'}, {}, {source});
  assert.equal(data['작성자'],'변경시험작성자');assert.equal(data['신규선택속성'],'읽기 시험');
 });
 await test('격리시험 sourcePath 원본 하나로 작동',async()=>{
  const p='시험원본/00-yaml 속성탭.md';assert.equal((await generate({}, {sourcePath:p},{sourcePath:p})).data['스키마버전'],'2.0.0');
 });
 const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
 for(const name of ['04-인물 설정 템플릿 V2 파일럿.md','04-인물 설정 템플릿 V2 빠른 시작.md']){
  await test(`실제 배포된 호출부 실행: ${name}`,async()=>{
   const text=fs.readFileSync(path.join(root,'인물 적용본',name),'utf8');const m=text.match(/^<%\*([\s\S]*?)%>/);
   assert(m);const {tp,state}=mock();const output=await new AsyncFunction('tp','tR',m[1]+'\nreturn tR;')(tp,'');
   assert.equal(parsed(output)['사용된 템플릿'],name.replace(/\.md$/,''));assert.equal(state.writes,0);
  });
 }
 const report={time:new Date().toISOString(),environment:'Node.js mock + PyYAML; no real Obsidian/Templater/Quartz',
  pass:results.filter(x=>x.result==='PASS').length,fail:results.filter(x=>x.result==='FAIL').length,results};
 fs.writeFileSync(path.join(__dirname,'생성기_모의검사.json'),JSON.stringify(report,null,2));
 console.log(JSON.stringify({pass:report.pass,fail:report.fail,failures:results.filter(x=>x.result==='FAIL')},null,2));
 if(report.fail)process.exitCode=1;
})();
