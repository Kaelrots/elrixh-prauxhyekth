---
# 공통 프론트매터의 유일한 작성 원본. 신규 문서 생성용이며 기존 문서 이관용이 아니다.
# @ 주석은 읽기 전용 생성기가 읽는 규칙이다. 별도 JS에 기본 양식을 복제하지 않는다.
# @forbid-new=태그|tag|별칭|카테고리|폴더|경로|물리위치

# 식별·분류
제목: <% JSON.stringify(tp.file.title) %> # @type=string @required @locked
aliases: [] # @type=list
문서유형: reference # @type=string @enum=master|concept|entity|reference|index|report|template|archive|event|period|rule|ledger
세부유형: null # @type=string @nullable @required
분야: [] # @type=list
tags: [] # @type=list
적용범위: [] # @type=list
연속성: [] # @type=list @optional
상위개념: [] # @type=list @optional
하위개념: [] # @type=list @optional

# 설정 지위·문서 진행도·배포 의도는 서로 독립적이다.
정본상태: draft # @type=string @enum=canon|provisional|draft|archival @locked
작성상태: outline # @type=string @enum=outline|partial|complete @locked
검토상태: unreviewed # @type=string @enum=unreviewed|reviewing|reviewed @locked
draft: true # @type=boolean @locked

# 현실의 문서 관리 시간. 세계관 생몰·사건일과 구분한다.
작성자: 현카엘 # @type=string @required
최초작성일: <% JSON.stringify(tp.date.now("YYYY-MM-DDTHH:mm:ss")) %> # @type=string @required @locked
최종수정일: <% JSON.stringify(tp.date.now("YYYY-MM-DDTHH:mm:ss")) %> # @type=string @required @locked
최근 변경 요약: "" # @type=string
문서버전: "0.1.0" # @type=string @required @locked
스키마버전: "2.0.0" # @type=string @required @locked
사용된 템플릿: null # @type=string @nullable @required
템플릿 버전: null # @type=string @nullable @required

# 기원·복원 출처. 신규 작성임을 알 때 original; 기존 문서의 결측값은 추정하지 않는다.
기원상태: original # @type=string @nullable @enum=original|restored
복원여부: false # @type=boolean @nullable @mirror-origin @locked
복원원문문서명: null # @type=string @nullable @optional @restore
복원원문최초작성일: null # @type=string @nullable @optional @restore
복원원문최종수정일: null # @type=string @nullable @optional @restore

# 조건부 공통 확장. 미사용 항목은 생성 결과에서 생략할 수 있다.
기준시점: null # @type=string @nullable @optional
최종검토일: null # @type=string @nullable @optional @locked
검토기준버전: null # @type=string @nullable @optional @locked
permalink: null # @type=string @nullable @optional
cssclasses: [] # @type=list @optional
---
